import 'package:chat_app/screens/chat_page.dart';
import 'package:chat_app/screens/register_page.dart';
import 'package:chat_app/widgets/custombutton.dart';
import 'package:chat_app/widgets/customtextfield.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import 'package:modal_progress_hud_nsn/modal_progress_hud_nsn.dart';

import '../helper/show_snack_bar.dart';

class LoginPage extends StatefulWidget {
  LoginPage({super.key});
  static String id = "LoginPage";

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool isLoading = false;
  String? password;
  String? email;

  GlobalKey<FormState> formKey = GlobalKey();

  @override
  Widget build(BuildContext context) {
    return ModalProgressHUD(
      inAsyncCall: isLoading,
      child: Scaffold(
        backgroundColor: Color(0xff2B475E),
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Form(
            key: formKey,
            child: ListView(
              padding: EdgeInsets.zero, // إزالة أي padding تلقائي من ListView
              children: [
                SizedBox(
                  height: 100,
                ),
                // التأكد من أن الصورة ليس لديها أي مسافة زائدة
                SizedBox(
                  height: 150,
                  width: 150,
                  child: Image.asset(
                    "assets/images/scholar.png",
                    scale: 1,
                  ),
                ),

                Center(
                  child: Text(
                    "Scholar Chat",
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 32,
                        fontFamily: "pacifico"),
                  ),
                ),
                SizedBox(
                  height: 20, // المسافة التالية للنص، يمكنك ضبطها كما تشاء
                ),
                Row(
                  children: [
                    Text(
                      "LOGIN",
                      style: TextStyle(color: Colors.white, fontSize: 20),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                CustomFormTextField(
                  onChanged: (data) {
                    email = data;
                  },
                  hintText: "Email",
                ),
                SizedBox(
                  height: 10,
                ),
                CustomFormTextField(
                  obscureText: true,
                  onChanged: (data) {
                    password = data;
                  },
                  hintText: "Password",
                ),
                SizedBox(
                  height: 10,
                ),
                CustomButon(
                  onTap: () async {
                    if (formKey.currentState!.validate()) {
                      isLoading = true;
                      setState(() {});
                      try {
                        await loginUser();
                        Navigator.pushNamed(context, ChatPage.id,
                            arguments: email);
                      } on FirebaseAuthException catch (ex) {
                        if (ex.code == "user-not-found") {
                          showSnackBar(
                              context, "No user found for that email.");
                        } else if (ex.code == "wrong-password") {
                          showSnackBar(context,
                              "Wrong password provided for that user.");
                        } else if (ex.code == "invalid-email") {
                          showSnackBar(
                              context, "The email address is not valid.");
                        } else if (ex.code == "user-disabled") {
                          showSnackBar(
                              context, "The email address is not valid.");
                        } else {
                          // عرض رسالة عامة في حالة حدوث خطأ غير متوقع
                          showSnackBar(
                              context, "An error occurred. Please try again.");
                        }
                      } catch (ex) {
                        print(ex);
                        showSnackBar(
                            context, "There was an error, please try again.");
                      } finally {
                        // إعادة تعيين حالة التحميل (إيقاف الـ spinner)
                        isLoading = false;
                        setState(() {});
                      }
                    }
                  },
                  text: "LOGIN",
                ),

                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "don\'t have an account?",
                      style: TextStyle(color: Colors.white),
                    ),
                    GestureDetector(
                      onTap: () {
                        Navigator.pushNamed(context, RegisterPage.id);
                      },
                      child: Text(
                        "  Register",
                        style: TextStyle(color: Color(0xffC7EDE6)),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Future<void> loginUser() async {
    UserCredential user = await FirebaseAuth.instance
        .signInWithEmailAndPassword(email: email!, password: password!);
  }
}

import 'dart:ui';

const kprimarycolor = Color(0xff2B475E);
const kMessagesCollection = "messages";
const kMessage = "message";
const kCreatedAt = "createdAt";
